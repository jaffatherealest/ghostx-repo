# GhostX changelog

## 0.2.0 — 2026-11-05
- Added per-container profile JSON (`Documents/ghostx-profile.json`).
- Added four-profile A11 table: iPhone10,3 / 10,6 / 10,2 / 10,1.
- Added auto mode: `postinst` creates `/var/mobile/Library/Preferences/com.sgwc.ghostx.auto`.
- Added MobileGestalt hooks (`ProductType`, `ProductVersion`, `BuildVersion`, `DeviceClass`, `IsSimulator`).
- Added UA rewrite in `NSMutableURLRequest` setters.
- Added `NSJSONSerialization` sanitizer for `deviceModel`/`osVersionNumber` before signing.
- Added `NSProcessInfo`, `UIDevice`, `UIScreen`, `NSLocale`, `__NSTimeZone`, `NSUserDefaults` hooks.
- Added `preferredLanguages=en-US`, `AppleLanguages`, `AppleLocale`.
- Added dyld image hiding, JB file checks, `getenv` hiding.
- Added packaging, install/uninstall scripts, README.

## 0.1.0 — 2026-11-05
- First working prototype: sysctl (`hw.machine`, `hw.product`, `hw.model`, `hw.target`, `hw.cpufamily`, CPU, memory, hostname, boot time), `uname`, dyld and file hooks.
- Verified load order: must load before `Ghost.dylib`.

## 0.3.0 — 2026-11-05
- Crashlytics on-disk scrubber: removes JB/tweak paths from `.clsrecord` files,
  rewrites `metadata.clsrecord` host model/machine/OS/locale, runs at launch and after 3/6/9 s.
- Corrected A11 board IDs: iPhone10,6 = D221AP, iPhone10,5 = D211AP, iPhone10,4 = D201AP.
- Explicit `ENOENT` for `hw.cpufrequency`, `FEAT_FGT`, `FEAT_NV`, `FEAT_DOTPROD`, `FEAT_PAN`.
- Added full IOSSecuritySuite 80+ path list to `NSFileManager` hiding.
- Removed unsafe libc `stat`/`access`/`fopen`/`open`/`opendir`/`fork` hooks after a CFBundle SIGBUS;
  narrowed path list is now used for `NSFileManager` and dyld hiding.
- Package 0.3.0.

## 0.4.0 — 2026-11-05
- Implemented `stat`, `access`, `fopen`, `fork` hooks (MSHookFunction) with the narrowed path list.
- Added `NSFileManager` hooks: `isReadableFileAtPath:`, `destinationOfSymbolicLinkAtPath:error:`,
  `contentsOfDirectoryAtPath:error:` (filters `/var/.jbroot-*`), `moveItemAtPath:toPath:error:`.
- IOSSecuritySuite `AmIJailbroken()` now returns `false` naturally; no Swift hook, no code patch.
- Crashlytics scrubber extended to report moves (`active` → `processing`/`prepared`) and 3/6/9/15/30/60 s.
- Added rootless paths `/var/jb`, `/cores/binpack`, `/var/Liy`, Dopamine/palera1n loader apps.
- Verified active Crashlytics report has 0 jailbreak/tweak paths; metadata host is profile.
- Package 0.4.0.

## 0.4.1 — 2026-11-05
- Added per-container `NSBundle.appStoreReceiptURL` spoof: receipt path now uses the container UUID.
- Added `getifaddrs` hook: hides `utun`/`ipsec`/`tap`/`ppp` and sets a per-container `en0` IPv4.
- Added `container_id`/`local_ip` to the profile JSON.
- Package 0.4.1.

## 0.6.1 — 2026-11-05
- Fixed new Crane containers not appearing: read `com.opa334.craneprefs.plist`
  directly instead of the process-cached CFPreferences value.
- Reload the container list when the Settings pane reappears.
- Fixed the Refresh button: set PSSpecifier `buttonAction`, not `action`.
- Package 0.6.1.

## 0.6.0 — 2026-11-05
- Added **Settings → GhostX** PreferenceLoader pane.
- Global `Enable GhostX` switch and one switch per X Crane container; default ON.
- Active container marked `(active)`; Refresh button.
- Preference path `/var/mobile/Library/Preferences/com.sgwc.ghostx.plist`
  (absolute file read; Crane's `CFFIXED_USER_HOME` does not hide it).
- Removed the CLI from the package; Settings is the on-phone control path.
- Added a local Sileo repo layout (`repo/`) and GitHub Pages publish script.

## 0.5.0 — 2026-11-05
- `CFNetworkCopySystemProxySettings` returns an empty dictionary while enabled: `AmIProxied()` is now false.
- Runtime ON/OFF gates on sysctl, uname, MobileGestalt, UA/client_data, UIDevice, NSProcessInfo, UIScreen, locale, timezone.
- Per-container `Documents/ghostx-disabled` marker; default is ON.
- Added `/var/jb/usr/bin/ghostxctl`:
  `ghostxctl list`, `ghostxctl off <uuid|all>`, `ghostxctl on <uuid|all>`.
- Receipt path and local IP are per-container.
- Package 0.5.0.

## Planned 0.7.0
- Castle token decode/validation.
- More model/OS profiles from real `sysctl -a` dumps.
- IOKit/disk/sensor coverage.
- A/B signup test results.
