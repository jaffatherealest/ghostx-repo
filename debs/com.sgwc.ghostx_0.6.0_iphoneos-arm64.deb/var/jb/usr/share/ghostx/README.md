# GhostX

Per-container device-surface normalizer for X (`com.atebits.Tweetie2`) under Crane.

## What it does
- Gives each Crane container a coherent device profile (model, board, CPU class, OS, screen, locale, timezone, boot time).
- Spoofs MobileGestalt, `sysctl`, `uname`, `NSProcessInfo`, `UIDevice`, `UIScreen`, `NSLocale`, `NSTimeZone`.
- Rewrites X's User-Agent and pre-signing `client_data` model fields to the profile.
- Hides Ghost/Crane/ellekit/libsandy/systemhook from dyld and JB file checks.
- Does **not** fake App Attest; the attestation remains genuine.

## Control (on the phone)
Open **Settings → GhostX**.

- `Enable GhostX` is the global switch, default ON.
- Each X Crane container has its own switch, default ON.
- The active container is marked `(active)`.
- Changes apply the next time X launches in that container.
- The UI only writes `/var/mobile/Library/Preferences/com.sgwc.ghostx.plist`; it does not need SSH, a terminal, an app icon, or an in-X gesture.

## Requirements
- Rootless jailbroken iPhone (`iphoneos-arm64`) with ElleKit.
- Crane installed.
- X 12.x (tested 12.40.1 on iOS 16.7.2).
- Rootful phones need a separate build.

## Install
See `docs/INSTALL-ROUTES.md`.

## Profile
`Documents/ghostx-profile.json` inside the container. Defaults are US:
`en_US` / `en-US` / `America/New_York`. Change locale/timezone to match the
proxy exit country.

## Auto mode warning
The postinst creates `/var/mobile/Library/Preferences/com.sgwc.ghostx.auto`
so containers without a profile use the defaults. All X Crane containers
therefore default to ON. Use **Settings → GhostX** to turn off any container
that should not be normalised.

## Build
```
THEOS=/tmp/theos make
THEOS=/tmp/theos make -C prefs
```
Then copy `.theos/obj/debug/GhostX.dylib` and
`prefs/.theos/obj/debug/GhostXPrefs.bundle` into `pkg/` and build the deb
(see `17-packaging-and-open-items.md`).

## Version
`VERSION` + `CHANGELOG.md`.
